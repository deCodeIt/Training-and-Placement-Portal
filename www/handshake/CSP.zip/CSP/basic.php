<html>
<title>home page</title>
<a href = 'signupform.php'>SIGN_UP</a><br>
<a href = 'loginform.php'>LOGIN</a><br>
<a href = 'signupformcompany.php'>SIGN_UP_company</a><br>
<a href = 'loginformcompany.php'>LOGIN_COMPANY</a>


</html>