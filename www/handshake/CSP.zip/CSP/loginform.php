<html>
<form action = 'loginquery.php' method = 'POST'>
ENTRY NUMBER:	</br><input type = 'text' name = 'entry_number' required></br></br>
PASSWORD:		</br><input type = 'password' name = 'password' required></br></br>
<input type = 'submit' value = 'login'></br>
<br>Not registered,sign up with us<br><a href = 'signupform.php' > SIGN_UP</a>
</form>
</html>
