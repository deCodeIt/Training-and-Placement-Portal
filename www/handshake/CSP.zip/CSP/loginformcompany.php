<html>
<form action = 'loginquerycompany.php' method = 'POST'>
COMPANY  EMAIL  ID:		</br><input type = 'email' size = 50 name ='email_id' required></br></br>
PASSWORD:		</br><input type = 'password' size = 50 name = 'password' required></br></br>
<input type = 'submit' value = 'login'></br>
</form>
</html>