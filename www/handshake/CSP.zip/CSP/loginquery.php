<?php
$servername = "localhost";//name of the server
$rootusername = "root";
$password = "";//password of the root user
$database_name = "hub_csp";
$table_name_for_students_info = "studentinfo";
// Create connection
$connect = mysqli_connect($servername,$rootusername,$password,$database_name);
//$database_selection = mysqli_select_db($servername,$rootusername,$password,$database_name);
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
<?php 
session_start();

?>

<?php 
$entry_no = $_POST['entry_number'];
$entry_no = mysqli_real_escape_string($connect,$entry_no);
//echo "$entry_no";
$pwd = $_POST['password'];
$pwd = mysqli_real_escape_string($connect,$pwd);
//SELECT column1,column2,column3... FROM tablename ;
$loginquery = "SELECT count(*) FROM $table_name_for_students_info where (entry_number = '$entry_no' and password = '$pwd')";
//echo $loginquery;
$query = mysqli_query($connect,$loginquery);

//numeric array

$res=mysqli_fetch_array($query);
//print_r($res);
if ($res[0] == 1){
	//print_r($_SESSION);
	$_SESSION['entry_num'] = $entry_no;
	echo "successful logged in.</br> WELCOME ".$_SESSION['entry_num'];
	echo "</br><a href = 'logout.php'>LOGOUT</a>";
}
else{
	echo "login failed";
	echo "</br><a href = 'signupform.php'>SIGN UP</a>";
	echo "</br><a href = 'loginform.php'>LOGIN</a>";
}


?>