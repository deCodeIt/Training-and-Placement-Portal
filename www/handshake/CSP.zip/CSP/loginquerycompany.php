<?php
$servername = "localhost";//name of the server
$rootusername = "root";
$password = "";//password of the root user
$database_name = "hub_csp";
$table_name = "companyinfo";
// Create connection
$connect = mysqli_connect($servername,$rootusername,$password,$database_name);

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
<?php 
session_start();
?>

<?php 
$email_id = $_POST['email_id'];
$email_id = mysqli_real_escape_string($connect,$email_id);
$pwd = $_POST['password'];
$pwd = mysqli_real_escape_string($connect,$pwd);
//SELECT column1,column2,column3... FROM tablename ;
$loginquery = "SELECT count(*) FROM $table_name where (company_email_id = '$email_id' and password = '$pwd')";
//$loginquery = "SELECT count(*) FROM $table_name_for_students_info where (entry_number = '$entry_no' and password = '$pwd')";
$query = mysqli_query($connect,$loginquery);

//numeric array

$res=mysqli_fetch_array($query);

//print_r($res);
if ($res[0] > 0){
	//print_r($_SESSION);
	$_SESSION['comany_name_id'] = $email_id;
	echo "successful logged in.</br> WELCOME ".$_SESSION['comany_name_id'];
	echo "</br><a href = 'logoutcompany.php'>LOGOUT</a>";
	echo "</br><a href = 'http://www.ibm.com/in/en/'>COMPANY_PAGE</a>";
}
else{
	echo "login failed";
	echo "</br><a href = 'signupformcompany.php'>SIGN UP</a>";
	echo "</br><a href = 'loginformcompany.php'>LOGIN</a>";
}


?>