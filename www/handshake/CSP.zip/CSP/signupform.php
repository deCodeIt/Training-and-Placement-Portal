<html>
<form action = 'signupquery.php' method = 'POST'>
EMAIL_ID:		</br><input type = 'email' name ='email_id'></br></br>
USERNAME:		</br><input type = 'text' name ='username' required></br></br>
ENTRY NUMBER:	</br><input type = 'text' name = 'entry_number' required></br></br>
PASSWORD:		</br><input type = 'password' name = 'password' required></br></br>
<input type = 'submit' value = 'sign_up'></br>
</form>
</html>