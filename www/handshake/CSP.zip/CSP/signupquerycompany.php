<?php
$servername = "localhost";//name of the server
$rootusername = "root";
$password = "";//password of the root user
$database_name = "hub_csp";
$table_name = "companyinfo";
// Create connection
$connect = mysqli_connect($servername,$rootusername,$password,$database_name);

if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>
<?php 
	$compemailadd = $_POST['email_id'];
	//$username = $_POST['username'];
	//$entry_no = $_POST['entry_number'];
	$passwd = $_POST['password'];
	//enter the field of the table in comanyinfo
	$enquire = "INSERT INTO $table_name (company_email_id,password) VALUES ('$compemailadd','$passwd')";
	$query = mysqli_query($connect,$enquire);
	//INSERT INTO table_name (column1,column2,column3,...)
	//VALUES (value1,value2,value3,...);
	
	if(!$query){
		echo "UNSuccessful SIGN UP ,please signup again <br>";
		echo "<a href = 'signupformcompany.php'>SIGN_UP</a>";
	}
	else{
		echo "HELLO company";
		//code that sends the mail to the user giving its field
	}
?>
